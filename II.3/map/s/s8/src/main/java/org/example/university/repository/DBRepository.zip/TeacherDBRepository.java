package org.example.university.repository;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.example.university.model.Teacher;

public class TeacherDBRepository extends DBRepository<Teacher> {

    public TeacherDBRepository(String DBUrl, String DBUser, String DBPassword) {
        super(DBUrl, DBUser, DBPassword);
    }

    @Override
    public void create(Teacher obj) {
        String sql = "INSERT INTO Teacher (ID, name) VALUES (?, ?)";
        try(PreparedStatement statement=connection.prepareStatement(sql))
        {
            statement.setInt(1,obj.getID());
            statement.setString(2,obj.getName());
            statement.executeUpdate();
        }catch(SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Teacher read(Integer id) {
        String sql = "SELECT * FROM Teacher WHERE ID = ?";
        try(PreparedStatement statement= connection.prepareStatement(sql))
        {
            statement.setInt(1,id);
            ResultSet resultSet=statement.executeQuery();
            if(resultSet.next())
            {
                return readFromResultSet(resultSet);
            }
            else
            {
                return null;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    @Override
    public void update(Teacher obj) {
        String sql = "UPDATE Teacher SET name = ? WHERE ID = ?";
        try(PreparedStatement statement=connection.prepareStatement(sql))
        {
            statement.setString(1,obj.getName());
            statement.setInt(2,obj.getID());
            statement.executeUpdate();
        }
        catch(SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void delete(Integer obj) {
        String sql = "DELETE FROM Teacher WHERE ID = ?";
        try(PreparedStatement statement=connection.prepareStatement(sql))
        {
            statement.setInt(1,obj);
            statement.executeUpdate();
        }
        catch(SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<Teacher> getAll() {
        String sql = "SELECT * FROM Teacher";
        try(PreparedStatement statement=connection.prepareStatement(sql))
        {
            ResultSet resultSet = statement.executeQuery();
            ArrayList<Teacher> teachers = new ArrayList<Teacher>();
            while(resultSet.next())
            {
                teachers.add(readFromResultSet(resultSet));
            }

            return teachers;
        }
        catch(SQLException e) {
            throw new RuntimeException(e);
        }
    }

    private static Teacher readFromResultSet(ResultSet resultSet) throws SQLException {
        return new Teacher(
                resultSet.getString("name"),
                resultSet.getInt("id")
        );
    }


}
