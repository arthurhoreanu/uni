package org.example.university.repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.example.university.model.HasID;

public abstract class DBRepository <T extends HasID> implements Repository<T>, AutoCloseable{
    protected Connection connection;
    DBRepository(String DBUrl, String DBUser, String DBPassword) {
        try
        {
            this.connection = DriverManager.getConnection(DBUrl, DBUser, DBPassword);
        }
        catch (SQLException e) {
            throw new RuntimeException(e);
        }
        }

    @Override
    public void close() throws Exception {
        connection.close();
    }
}
