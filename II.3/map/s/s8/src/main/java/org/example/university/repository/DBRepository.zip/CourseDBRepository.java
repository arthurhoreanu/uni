package org.example.university.repository;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.example.university.model.Course;
import org.example.university.model.Teacher;

public class CourseDBRepository extends DBRepository<Course> {
    TeacherDBRepository teacherDBRepository;
    CourseDBRepository(String DBUrl, String DBUser, String DBPassword) {
        super(DBUrl, DBUser, DBPassword);
        teacherDBRepository = new TeacherDBRepository(DBUrl, DBUser, DBPassword);
    }

    @Override
    public void create(Course obj) {
        String sqlQuery = "INSERT INTO Course (ID, availableSlots, credits, courseName, teacherID) VALUES(?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sqlQuery)) {
            statement.setInt(1, obj.getID());
            statement.setInt(2, obj.getAvailableSlots());
            statement.setInt(3, obj.getCredits());
            statement.setString(4, obj.getCourseName());
            statement.setInt(5, obj.getTeacher().getID());

            statement.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Course read(Integer id) {
        String sqlQuery = "SELECT * FROM Course WHERE ID = ?";
        try (PreparedStatement statement = connection.prepareStatement(sqlQuery)) {
            statement.setInt(1, id);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                Course c = readFromResultSet(resultSet);
                return c;
            }
            else{
                return null;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    private Course readFromResultSet(ResultSet resultSet) throws SQLException {
        Teacher teacher = teacherDBRepository.read(resultSet.getInt("teacherID"));
        Course c = new Course(resultSet.getInt("ID"),
                resultSet.getString("courseName"),
                teacher,
                resultSet.getInt("availableSlots"),
                resultSet.getInt("credits"));
        return c;
    }

    @Override
    public void update(Course obj) {
        String sqlQuery = "UPDATE Course SET availableSlots = ?, credits = ?, courseName=?, teacherID=? WHERE ID = ?";
        try(PreparedStatement statement = connection.prepareStatement(sqlQuery)) {
            statement.setInt(1, obj.getAvailableSlots());
            statement.setInt(2, obj.getCredits());
            statement.setString(3, obj.getCourseName());
            statement.setInt(4, obj.getTeacher().getID());
            statement.setInt(5, obj.getID());

            statement.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void delete(Integer obj) {
        String sqlQuery = "DELETE FROM Course WHERE ID = ?";
        try(PreparedStatement statement = connection.prepareStatement(sqlQuery)) {
            statement.setInt(1, obj);
            statement.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        String sqlQuery2 = "DELETE FROM StudentCourse WHERE CourseId = ?";
        try(PreparedStatement statement = connection.prepareStatement(sqlQuery2)) {
            statement.setInt(1, obj);
            statement.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<Course> getAll() {
        String sqlQuery = "SELECT * FROM Course";
        try(PreparedStatement statement = connection.prepareStatement(sqlQuery)) {
            ResultSet resultSet = statement.executeQuery();
            List<Course> courses = new ArrayList<Course>();
            while(resultSet.next()) {
                courses.add(readFromResultSet(resultSet));
            }
            return courses;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
