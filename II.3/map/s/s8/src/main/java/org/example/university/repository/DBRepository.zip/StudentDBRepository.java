package org.example.university.repository;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.example.university.model.Course;
import org.example.university.model.Student;

public class StudentDBRepository extends DBRepository<Student> {
    StudentDBRepository(String DBUrl, String DBUser, String DBPassword) {
        super(DBUrl, DBUser, DBPassword);
    }

    @Override
    public void create(Student obj) {
        String SQL = "insert into Student (ID, name) values (?,?)";
        try(PreparedStatement statement = connection.prepareStatement(SQL)){
            statement.setInt(1, obj.getID());
            statement.setString(2, obj.getName());
            statement.executeUpdate();
        }
        catch(SQLException e){throw new RuntimeException(e);}
    }

    @Override
    public Student read(Integer id) {
        String SQL = "select * from Student where ID = ?";
        try(PreparedStatement statement = connection.prepareStatement(SQL)){
            statement.setInt(1, id);
            ResultSet rs = statement.executeQuery();
            if(rs.next()){
                return readFromResultSet(rs);
            }
            else return null;
        }
        catch(SQLException e){throw new RuntimeException(e);}
    }

    private static Student readFromResultSet(ResultSet rs) throws SQLException {
        return new Student(
                rs.getString("name"),
                rs.getInt("ID")
        );
    }

    @Override
    public void update(Student obj) {
        String SQL = "update Student set name = ? where ID = ?";
        try(PreparedStatement statement = connection.prepareStatement(SQL)){
            statement.setString(1, obj.getName());
            statement.setInt(2, obj.getID());
            statement.executeUpdate();
        }
        catch(SQLException e){throw new RuntimeException(e);}
        String SQL2 = "delete from StudentCourse where StudentID = ?";
        try(PreparedStatement statement = connection.prepareStatement(SQL2)){
            statement.setInt(1, obj.getID());
            statement.executeUpdate();
        }
        catch(SQLException e){throw new RuntimeException(e);}
        String SQL3 = "insert into StudentCourse (StudentID, CourseID) values (?,?)";
        for (Course course : obj.getCourses()) {
            try(PreparedStatement statement = connection.prepareStatement(SQL3)){
                statement.setInt(1, obj.getID());
                statement.setInt(2, course.getID());
                statement.executeUpdate();
            }
            catch(SQLException e){throw new RuntimeException(e);}
        }
    }

    @Override
    public void delete(Integer obj) {
        String SQL = "delete from Student where ID = ?";
        try(PreparedStatement statement = connection.prepareStatement(SQL)) {
            statement.setInt(1, obj);
            statement.executeUpdate();
        }
        catch(SQLException e){throw new RuntimeException(e);}
    }

    @Override
    public List<Student> getAll() {
        String SQL = "select * from Student";
        try(PreparedStatement statement = connection.prepareStatement(SQL)){
            ResultSet resultSet = statement.executeQuery();
            List<Student> students = new ArrayList<Student>();
            while(resultSet.next()){
                students.add(readFromResultSet(resultSet));
            }
            return students;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
